"""Точка входа в игру «Побег из Светофора».

Запуск:  python main.py
"""
from game import start_game


if __name__ == '__main__':
    start_game()